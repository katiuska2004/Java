
// Superclase Formas
public abstract class Formas {
    private String color;

    public Formas(String color) {
        this.color = color;
    }

    public abstract void dibujar();

    public String getColor() {
        return color;
    }
}

// Subclase Circulo
public class Circulo extends Formas {
    private double radio;

    public Circulo(String color, double radio) {
        super(color);
        this.radio = radio;
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un círculo de color " + getColor() + " con radio " + radio);
    }

    public double getRadio() {
        return radio;
    }
}

// Subclase Rectangulo
public class Rectangulo extends Formas {
    private double ancho;
    private double alto;

    public Rectangulo(String color, double ancho, double alto) {
        super(color);
        this.ancho = ancho;
        this.alto = alto;
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un rectángulo de color " + getColor() + " con ancho " + ancho + " y alto " + alto);
    }

    public double getAncho() {
        return ancho;
    }

    public double getAlto() {
        return alto;
    }
}

// Subclase Triangulo
public class Triangulo extends Formas {
    private double base;
    private double altura;

    public Triangulo(String color, double base, double altura) {
        super(color);
        this.base = base;
        this.altura = altura;
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un triángulo de color " + getColor() + " con base " + base + " y altura " + altura);
    }

    public double getBase() {
        return base;
    }

    public double getAltura() {
        return altura;
    }
}

// Subclase Cuadrado
public class Cuadrado extends Rectangulo {
    public Cuadrado(String color, double lado) {
        super(color, lado, lado);
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un cuadrado de color " + getColor() + " con lado " + getAncho());
    }
}

// Clase principal para probar
public class Main {
    public static void main(String[] args) {
        Formas[] formas = new Formas[] {
            new Circulo("rojo", 5),
            new Rectangulo("azul", 4, 6),
            new Triangulo("verde", 3, 4),
            new Cuadrado("amarillo", 4)
        };

        for (Formas forma : formas) {
            forma.dibujar();
        }
    }
}
